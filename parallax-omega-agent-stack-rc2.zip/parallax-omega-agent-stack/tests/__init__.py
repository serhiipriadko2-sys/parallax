"""PARALLAX Ω test package."""
